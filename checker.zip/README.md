# checker
A useful checker for OI

## install
```bash
./install.sh
checker -h
```

## usage:
```
checker [$problem_name] [-v] [-l] [-c] [-q] [-f] [-u]

-f: fast mode
-l: always load problem file
-c: always continue when error occurs
-q: always quit when error occors
-v: check version and quit
-u: update
```

current version: 5.4
