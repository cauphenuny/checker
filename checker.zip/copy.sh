#!/bin/sh
cp ./checker /usr/local/bin/checker 2>/dev/null 1>&2
