#!/bin/sh
echo "compile checker.cpp ..."
g++ checker.cpp -o checker -lreadline
./upload.sh
